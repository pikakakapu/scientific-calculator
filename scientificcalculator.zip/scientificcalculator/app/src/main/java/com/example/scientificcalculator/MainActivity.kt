package com.example.scientificcalculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

class MainActivity : AppCompatActivity() {

    private lateinit var expressionInput: EditText
    private lateinit var resultOutput: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        expressionInput = findViewById(R.id.expressionInput)
        resultOutput = findViewById(R.id.resultOutput)

        // Set up button listeners
        val buttons = listOf(
            R.id.button0, R.id.button1, R.id.button2, R.id.button3,
            R.id.button4, R.id.button5, R.id.button6, R.id.button7,
            R.id.button8, R.id.button9, R.id.buttonAdd, R.id.buttonSubtract,
            R.id.buttonMultiply, R.id.buttonDivide, R.id.buttonDot,
            R.id.buttonSin, R.id.buttonCos, R.id.buttonTan, R.id.buttonSqrt,
            R.id.buttonOpenBracket, R.id.buttonCloseBracket, R.id.buttonPower,
            R.id.buttonEquals, R.id.buttonClear
        )

        for (buttonId in buttons) {
            findViewById<Button>(buttonId).setOnClickListener {
                val button = it as Button
                when (button.id) {
                    R.id.buttonClear -> {
                        expressionInput.text.clear()
                        resultOutput.text = "0"
                    }
                    R.id.buttonEquals -> {
                        try {
                            val result = evaluateExpression(expressionInput.text.toString())
                            resultOutput.text = result.toString()
                        } catch (e: Exception) {
                            resultOutput.text = "Error: ${e.message}"
                        }
                    }
                    else -> {
                        expressionInput.append(button.text)
                    }
                }
            }
        }
    }

    private fun evaluateExpression(expression: String): Double {
        return ExpressionEvaluator.evaluate(expression)
    }
}

object ExpressionEvaluator {

    fun evaluate(expression: String): Double {
        return Parser(expression).parse()
    }

    private class Parser(private val expression: String) {
        private var pos = -1
        private var ch = 0

        private fun nextChar() {
            ch = if (++pos < expression.length) expression[pos].code else -1
        }

        private fun eat(charToEat: Int): Boolean {
            while (ch == ' '.code) nextChar()
            if (ch == charToEat) {
                nextChar()
                return true
            }
            return false
        }

        fun parse(): Double {
            nextChar()
            val x = parseExpression()
            if (pos < expression.length) throw RuntimeException("Unexpected character: ${ch.toChar()}")
            return x
        }

        private fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                when {
                    eat('+'.code) -> x += parseTerm()
                    eat('-'.code) -> x -= parseTerm()
                    else -> return x
                }
            }
        }

        private fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                when {
                    eat('*'.code) -> x *= parseFactor()
                    eat('/'.code) -> x /= parseFactor()
                    else -> return x
                }
            }
        }

        private fun parseFactor(): Double {
            if (eat('+'.code)) return parseFactor()
            if (eat('-'.code)) return -parseFactor()

            var x: Double
            val startPos = pos
            if (eat('('.code)) {
                x = parseExpression()
                if (!eat(')'.code)) throw RuntimeException("Missing closing bracket")
            } else if (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) {
                while (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) nextChar()
                x = expression.substring(startPos, pos).toDouble()
            } else if (ch >= 'a'.code && ch <= 'z'.code) {
                while (ch >= 'a'.code && ch <= 'z'.code) nextChar()
                val func = expression.substring(startPos, pos)
                x = parseFactor()
                x = when (func) {
                    "sin" -> sin(Math.toRadians(x))
                    "cos" -> cos(Math.toRadians(x))
                    "tan" -> tan(Math.toRadians(x))
                    "√" -> sqrt(x)
                    else -> throw RuntimeException("Unknown function: $func")
                }
            } else {
                throw RuntimeException("Unexpected character: ${ch.toChar()}")
            }

            if (eat('^'.code)) x = x.pow(parseFactor())
            return x
        }
    }
}